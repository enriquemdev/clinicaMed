CREATE DATABASE IF NOT EXISTS `bdcleanfull`;

USE `bdcleanfull`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `catcaja`;

CREATE TABLE `catcaja` (
  `idCaja` int(11) NOT NULL AUTO_INCREMENT,
  `nombreCaja` varchar(100) NOT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `EstadoCaja` tinyint(4) NOT NULL,
  PRIMARY KEY (`idCaja`),
  KEY `EstadoCaja` (`EstadoCaja`),
  CONSTRAINT `catcaja_ibfk_1` FOREIGN KEY (`EstadoCaja`) REFERENCES `catestado` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catcaja` VALUES (1,"Caja 1 ClinicaMedica","Caja de clinica medica",2),
(2,"Caja 2","Segunda caja",1),
(3,"caja 3",3,2);


DROP TABLE IF EXISTS `catcargos`;

CREATE TABLE `catcargos` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(60) DEFAULT NULL,
  `Descripcion` varchar(200) DEFAULT NULL,
  `FechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catcargos` VALUES (1,"Enfermera","Profesional","2022-09-30 00:00:00"),
(2,"Doctor","Profesional","2022-09-30 00:00:00"),
(3,"Recepcionista","Profesional","2022-09-30 00:00:00"),
(4,"Cajero","Profesional","2022-09-30 00:00:00"),
(5,"Gerente","Profesional","2022-09-30 00:00:00"),
(6,"Doctor radiologico","Profesional","2022-09-30 00:00:00"),
(7,"Administrador","Profesional","2022-09-30 00:00:00"),
(8,"Farmaceuta","Profesional","2022-09-30 00:00:00");


DROP TABLE IF EXISTS `catconsultorio`;

CREATE TABLE `catconsultorio` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(60) DEFAULT NULL,
  `Descripcion` varchar(200) DEFAULT NULL,
  `FechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catconsultorio` VALUES (1,"Consultorio 1","Sala de consulta","2022-09-30 00:00:00"),
(2,"Consultorio 2","Sala de consulta","2022-09-30 00:00:00");


DROP TABLE IF EXISTS `catenfermedades`;

CREATE TABLE `catenfermedades` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NombreEnfermedad` varchar(40) NOT NULL,
  `Descripcion` varchar(200) DEFAULT NULL,
  `TipoEnfermedad` varchar(30) DEFAULT NULL,
  `FechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catenfermedades` VALUES (1,"Bronquitis aguda","Enfermedad comun","Respiratoria","2022-09-30 00:00:00"),
(2,"Resfriado común","Enfermedad comun","Respiratoria","2022-09-30 00:00:00"),
(3,"Influenza","Enfermedad comun","Respiratoria","2022-09-30 00:00:00"),
(4,"COVID 19","Enfermedad mortal","Respiratoria","2022-09-30 00:00:00"),
(5,"VIH","Enfermedad mortal","ITS","2022-09-30 00:00:00"),
(6,"SIDA","Enfermedad mortal","ITS","2022-09-30 00:00:00"),
(7,"Sifilis","Enfermedad mortal","ITS","2022-09-30 00:00:00"),
(8,"Gonorrea","Enfermedad mortal","ITS","2022-09-30 00:00:00"),
(9,"Evola","Enfermedad mortal","Respiratoria","2022-09-30 00:00:00"),
(10,"Dengue","Enfermedad mortal","Febril","2022-09-30 00:00:00");


DROP TABLE IF EXISTS `catespecialidades`;

CREATE TABLE `catespecialidades` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(80) DEFAULT NULL,
  `Descripcion` varchar(200) DEFAULT NULL,
  `FechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catespecialidades` VALUES (1,"Pediatria","Especialista","2022-09-30 00:00:00"),
(2,"Nutriologia","Especialista","2022-09-30 00:00:00"),
(3,"Cardiologia","Especialista","2022-09-30 00:00:00"),
(4,"Gastroenterología","Especialista","2022-09-30 00:00:00"),
(5,"Rinoplastia","Especialista","2022-09-30 00:00:00");


DROP TABLE IF EXISTS `catestado`;

CREATE TABLE `catestado` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NombreEstado` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catestado` VALUES (1,"Activo"),
(2,"Inactivo"),
(3,"Espera"),
(4,"Negado"),
(5,"Abierto"),
(6,"Cerrado");


DROP TABLE IF EXISTS `catestadocita`;

CREATE TABLE `catestadocita` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catestadocita` VALUES (1,"Activo"),
(2,"Inactivo");


DROP TABLE IF EXISTS `catestadocivil`;

CREATE TABLE `catestadocivil` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catestadocivil` VALUES (1,"Solter@"),
(2,"Casad@");


DROP TABLE IF EXISTS `catestadocompra`;

CREATE TABLE `catestadocompra` (
  `idEstadoCompra` int(11) NOT NULL AUTO_INCREMENT,
  `nombreEstado` varchar(60) NOT NULL,
  PRIMARY KEY (`idEstadoCompra`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catestadocompra` VALUES (1,"Solicitado"),
(2,"Autorizado"),
(3,"Terminado"),
(4,"Rechazado"),
(5,"Revertdio"),
(6,"Recibido completo"),
(7,"Recibido parcial"),
(8,"Recibido erroneo");


DROP TABLE IF EXISTS `catestadoconsulta`;

CREATE TABLE `catestadoconsulta` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catestadoconsulta` VALUES (1,"Asignada"),
(2,"En Espera"),
(3,"Prioridad"),
(4,"Revertida"),
(5,"Terminada"),
(6,"En proceso");


DROP TABLE IF EXISTS `catestadoservicios`;

CREATE TABLE `catestadoservicios` (
  `idEstadoServicio` int(11) NOT NULL AUTO_INCREMENT,
  `nombreEstadoServicio` varchar(100) NOT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idEstadoServicio`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catestadoservicios` VALUES (1,"Pago Pendiente","No se ha pagado nada del servicio aun"),
(2,"Pago Semi-pendiente","Ya se ha realizado un adelanto del pago, pero aun no se paga el valor total neto."),
(3,"Pago Finalizado","Se ha cancelado el valor total neto del servicio");


DROP TABLE IF EXISTS `catestadosmedicos`;

CREATE TABLE `catestadosmedicos` (
  `idEstadoMedico` int(11) NOT NULL AUTO_INCREMENT,
  `nombreEstadoMedico` varchar(100) NOT NULL,
  PRIMARY KEY (`idEstadoMedico`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catestadosmedicos` VALUES (1,"Activo"),
(2,"En Espera"),
(3,"Denegado");


DROP TABLE IF EXISTS `catexamenesmedicos`;

CREATE TABLE `catexamenesmedicos` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) DEFAULT NULL,
  `Precio` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catexamenesmedicos` VALUES (1,"Radiografia",300),
(2,"Sangre general",100),
(3,"Tomografía",250),
(4,"Orina",50);


DROP TABLE IF EXISTS `catgenero`;

CREATE TABLE `catgenero` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catgenero` VALUES (1,"M"),
(2,"F");


DROP TABLE IF EXISTS `catgruposanguineo`;

CREATE TABLE `catgruposanguineo` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(3) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catgruposanguineo` VALUES (1,"O-"),
(2,"O+"),
(3,"A-"),
(4,"A+"),
(5,"B-"),
(6,"B+"),
(7,"AB-"),
(8,"AB+");


DROP TABLE IF EXISTS `catlaboratorio`;

CREATE TABLE `catlaboratorio` (
  `idLaboratorio` int(11) NOT NULL AUTO_INCREMENT,
  `nombreLaboratorio` varchar(80) NOT NULL,
  `descripcionLaboratorio` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idLaboratorio`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catlaboratorio` VALUES (1,"LABORATORIOS RARPE","Son tuanis loco"),
(2,"LABORATORIOS BAYER","Son tuanis loco"),
(3,"LABORATORIOS RAMOS","Son tuanis loco");


DROP TABLE IF EXISTS `catmaquinaria`;

CREATE TABLE `catmaquinaria` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NombreMaquinaria` varchar(80) DEFAULT NULL,
  `Descripcion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catmaquinaria` VALUES (1,"Esterilizadores","Equipo medico"),
(2,"Desfibriladores","Equipo medico");


DROP TABLE IF EXISTS `catmedicamentos`;

CREATE TABLE `catmedicamentos` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nombreComercial` varchar(40) NOT NULL,
  `nombreGenerico` varchar(40) NOT NULL,
  `formula` varchar(100) NOT NULL,
  `presentacion` varchar(40) NOT NULL,
  `descripcionMedicamento` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catmedicamentos` VALUES (1,"Omeprazol","Omeprazol","asd","asd","asd"),
(2,"Paracetamol","Paracetamol","asd","asd","asd"),
(3,"Acetaminofen","Acetaminofen","asd","asd","asd"),
(4,"Salbutamol","Salbutamol","asd","asd","asd"),
(5,"Ketotifeno","Ketotifeno","asd","asd","asd");


DROP TABLE IF EXISTS `catmetodosdepago`;

CREATE TABLE `catmetodosdepago` (
  `idMetodoPago` int(11) NOT NULL AUTO_INCREMENT,
  `NombreMetodoPago` varchar(100) NOT NULL,
  `Descripcion` varchar(255) NOT NULL,
  PRIMARY KEY (`idMetodoPago`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catmetodosdepago` VALUES (1,"Contado","Pago en efectivo"),
(3,"Tarjeta LAFISE","Pago por medio de tarjeta LAFISE"),
(4,"Tarjeta BAC","Del banco bac");


DROP TABLE IF EXISTS `catmodulos`;

CREATE TABLE `catmodulos` (
  `CodModulo` int(11) NOT NULL AUTO_INCREMENT,
  `NombreModulo` varchar(30) NOT NULL,
  `DescripcionModulo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CodModulo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catmodulos` VALUES (1,"Cita","Modulo cita"),
(2,"Usuarios","Modulo usuarios"),
(3,"Empleados","Modulo empleados"),
(4,"Paciente","Modulo paciente"),
(5,"Consulta","Modulo consulta"),
(6,"Examen","Modulo examen"),
(7,"Caja","Modulo caja"),
(8,"Catalogos","Modulo catalogos"),
(9,"Farmacia","Modulo farmacia");


DROP TABLE IF EXISTS `catmoneda`;

CREATE TABLE `catmoneda` (
  `idMoneda` int(11) NOT NULL AUTO_INCREMENT,
  `nombreMoneda` varchar(100) NOT NULL,
  `simbolo` varchar(2) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `EsReferencia` tinyint(4) NOT NULL,
  PRIMARY KEY (`idMoneda`),
  KEY `EsReferencia` (`EsReferencia`),
  CONSTRAINT `catmoneda_ibfk_1` FOREIGN KEY (`EsReferencia`) REFERENCES `catestado` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catmoneda` VALUES (1,"Cordoba","C$","Moneda nicaraguense",1),
(2,"Dolar","$","Moneda estado unidence",2);


DROP TABLE IF EXISTS `catnivelacademico`;

CREATE TABLE `catnivelacademico` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `NombreNivelAcademico` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catnivelacademico` VALUES (1,"Secundaria"),
(2,"Universitario"),
(3,"Maestria"),
(4,"Doctorado");


DROP TABLE IF EXISTS `catparentesco`;

CREATE TABLE `catparentesco` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(40) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catparentesco` VALUES (1,"No relación"),
(2,"Padre"),
(3,"Madre");


DROP TABLE IF EXISTS `catprivilegio`;

CREATE TABLE `catprivilegio` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `NombrePrivilegio` varchar(30) NOT NULL,
  `Descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catprivilegio` VALUES (1,"Agregar","Agregar Registros"),
(2,"Ver","Ver Registros"),
(3,"Actualizar","Actualizar Registros");


DROP TABLE IF EXISTS `catsalaexamen`;

CREATE TABLE `catsalaexamen` (
  `ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(60) DEFAULT NULL,
  `Dimensiones` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catsalaexamen` VALUES (1,"Sala examen 1","2x2"),
(2,"Sala examen 2","3x3");


DROP TABLE IF EXISTS `catservicios`;

CREATE TABLE `catservicios` (
  `idServicio` int(11) NOT NULL AUTO_INCREMENT,
  `nombreServicio` varchar(100) NOT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `PrecioGeneral` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`idServicio`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catservicios` VALUES (1,"Examen","Un examen alcorazon",500),
(2,"Consulta general","Una consulta general",300),
(3,"Venta medicamentos","Una venta de medicamentos",NULL);


DROP TABLE IF EXISTS `catsintomas`;

CREATE TABLE `catsintomas` (
  `idSintoma` int(11) NOT NULL AUTO_INCREMENT,
  `nombreSintoma` varchar(100) NOT NULL,
  `descripcionSintoma` varchar(255) DEFAULT NULL,
  `estadoSintoma` int(11) NOT NULL,
  PRIMARY KEY (`idSintoma`),
  KEY `estadoSintoma` (`estadoSintoma`),
  CONSTRAINT `catsintomas_ibfk_1` FOREIGN KEY (`estadoSintoma`) REFERENCES `catestadosmedicos` (`idEstadoMedico`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catsintomas` VALUES (1,"Calentura","Temperatura corporal elevada",1),
(2,"Tos","Tos fea",1),
(3,"Secrecion nasal","moquera",1),
(4,"Dolor de estomago","Dolor Estomacal",1),
(5,"Dolor de cabeza","Dolor en la Cabeza",1),
(6,"Diarrea",NULL,2),
(7,"fiebre",NULL,2);


DROP TABLE IF EXISTS `catsubmodulos`;

CREATE TABLE `catsubmodulos` (
  `CodSubModulo` int(11) NOT NULL AUTO_INCREMENT,
  `NombreSubModulo` varchar(30) NOT NULL,
  `DescripcionSubModulo` varchar(100) DEFAULT NULL,
  `CodigoModulo` int(11) NOT NULL,
  PRIMARY KEY (`CodSubModulo`),
  KEY `CodigoModulo` (`CodigoModulo`),
  CONSTRAINT `catsubmodulos_ibfk_1` FOREIGN KEY (`CodigoModulo`) REFERENCES `catmodulos` (`CodModulo`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;

INSERT INTO `catsubmodulos` VALUES (1,"Cita","Submodulo Cita",1),
(2,"Usuarios","Submodulo Usuarios",2),
(3,"Empleados","Submodulo Empleados",3),
(4,"Especialidades","Submodulo Empleados",3),
(5,"Estudios Académicos","Submodulo Empleados",3),
(6,"Familiares Empleado","Submodulo Empleados",3),
(7,"Historial Cargos","Submodulo Empleados",3),
(8,"Paciente","Submodulo Paciente",4),
(9,"Antecedentes","Submodulo Paciente",4),
(10,"Familiares Paciente","Submodulo Paciente",4),
(11,"Ocupacion Paciente","Submodulo Paciente",4),
(12,"Consulta","Submodulo Consulta",5),
(13,"Signos Vitales","Submodulo Consulta",5),
(14,"Diagnóstico","Submodulo Consulta",5),
(15,"Receta Médica","Submodulo Consulta",5),
(16,"Receta Examen","Submodulo Consulta",5),
(17,"Constancia","Submodulo Consulta",5),
(18,"Examen","Submodulo Examen",6),
(19,"Resultados","Submodulo Examen",6),
(20,"Maquinaria Médica","Submodulo Examen",6),
(21,"Catalogos","Submodulo Catalogos",8),
(22,"SolicitudConsulta","Donde la recepcionista solicita la consulta hacia el medico.",5),
(23,"InventarioFarmacia","Inventario para farmacia",9),
(24,"ComprasFarmacia","Compras para farmacia",9),
(25,"VentasFarmacia","Ventas para farmacia",9),
(26,"DetalleCompraFarmacia","Detalle de la compra de la farmacia",9),
(27,"DetalleVentaFarmacia","Detalle de la venta de la farmacia",9),
(28,"Realizar Cobro","Proceso normal de la gestion de cobro de servicios de la clinica",7);


DROP TABLE IF EXISTS `tblantecedentes`;

CREATE TABLE `tblantecedentes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CodPaciente` int(11) NOT NULL,
  `Enfermedad` tinyint(4) NOT NULL,
  `FechaAparicion` date DEFAULT NULL,
  `Descripcion` varchar(200) NOT NULL,
  `Tratamiento` varchar(200) NOT NULL,
  `Notas` varchar(200) DEFAULT NULL,
  `EsGenetico` tinyint(4) NOT NULL,
  `EstadoAntecedente` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CodPaciente` (`CodPaciente`),
  KEY `Enfermedad` (`Enfermedad`),
  KEY `EstadoAntecedente` (`EstadoAntecedente`),
  CONSTRAINT `tblantecedentes_ibfk_1` FOREIGN KEY (`CodPaciente`) REFERENCES `tblpaciente` (`CodigoP`),
  CONSTRAINT `tblantecedentes_ibfk_2` FOREIGN KEY (`Enfermedad`) REFERENCES `catenfermedades` (`ID`),
  CONSTRAINT `tblantecedentes_ibfk_3` FOREIGN KEY (`EstadoAntecedente`) REFERENCES `catestado` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblaperturacaja`;

CREATE TABLE `tblaperturacaja` (
  `idApertura` int(11) NOT NULL AUTO_INCREMENT,
  `Caja` int(11) NOT NULL,
  `MontoInicial` decimal(10,2) NOT NULL,
  `EmpleadoCaja` int(11) NOT NULL,
  `FyHInicio` datetime NOT NULL,
  `FyHCierre` datetime DEFAULT NULL,
  `direccionMAC` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`idApertura`),
  KEY `EmpleadoCaja` (`EmpleadoCaja`),
  KEY `Caja` (`Caja`),
  CONSTRAINT `tblaperturacaja_ibfk_1` FOREIGN KEY (`EmpleadoCaja`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblaperturacaja_ibfk_2` FOREIGN KEY (`Caja`) REFERENCES `catcaja` (`idCaja`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblaperturacaja` VALUES (20,3,"0.00",5,"2022-09-26 21:49:52","2022-09-26 21:54:43","0A-00-27-00-00-12"),
(21,2,"0.00",5,"2022-09-26 21:54:48","2022-09-27 22:17:16","0A-00-27-00-00-12"),
(22,1,"3000.00",5,"2022-09-27 22:18:59","2022-09-27 22:29:29","0A-00-27-00-00-12"),
(23,1,"1000.00",5,"2022-10-13 14:06:15","2022-10-20 09:49:34","98-43-FA-7C-61-85"),
(24,2,"100.00",5,"2022-10-20 09:49:43",NULL,"98-43-FA-7C-61-85");


DROP TABLE IF EXISTS `tblasignacionlote`;

CREATE TABLE `tblasignacionlote` (
  `idAsignacionLote` int(11) NOT NULL AUTO_INCREMENT,
  `detSoliCompra` int(11) NOT NULL,
  `lote` int(11) NOT NULL,
  `asgindadoYa` int(11) NOT NULL,
  PRIMARY KEY (`idAsignacionLote`),
  KEY `detSoliCompra` (`detSoliCompra`),
  KEY `lote` (`lote`),
  CONSTRAINT `tblasignacionlote_ibfk_1` FOREIGN KEY (`detSoliCompra`) REFERENCES `tbldetsolicitudcompra` (`idDetSolicitudCompra`),
  CONSTRAINT `tblasignacionlote_ibfk_2` FOREIGN KEY (`lote`) REFERENCES `tbllotemedicamento` (`idLote`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblasignacionlote` VALUES (1,1,1,90),
(2,3,2,20),
(3,2,3,60),
(4,5,4,50),
(5,5,5,50),
(6,7,6,3),
(7,7,7,2);


DROP TABLE IF EXISTS `tblcita`;

CREATE TABLE `tblcita` (
  `IDCita` int(11) NOT NULL AUTO_INCREMENT,
  `CodPaciente` int(11) NOT NULL,
  `fechaProgramada` date DEFAULT NULL,
  PRIMARY KEY (`IDCita`),
  KEY `CodPaciente` (`CodPaciente`),
  CONSTRAINT `tblcita_ibfk_1` FOREIGN KEY (`CodPaciente`) REFERENCES `tblpaciente` (`CodigoP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblclientes`;

CREATE TABLE `tblclientes` (
  `idCliente` int(11) NOT NULL AUTO_INCREMENT,
  `CodPersona` int(11) NOT NULL,
  `FechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`idCliente`),
  KEY `CodPersona` (`CodPersona`),
  CONSTRAINT `tblclientes_ibfk_1` FOREIGN KEY (`CodPersona`) REFERENCES `tblpersona` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblclientes` VALUES (1,9,"2022-10-13 14:06:43"),
(2,10,"2022-10-19 19:36:10"),
(3,12,"2022-10-31 16:54:10");


DROP TABLE IF EXISTS `tblcompra`;

CREATE TABLE `tblcompra` (
  `idCompra` int(11) NOT NULL AUTO_INCREMENT,
  `solicitudCompra` int(11) NOT NULL,
  `estadoCompra` int(11) NOT NULL,
  `nota` varchar(255) NOT NULL,
  `fechaRecibido` date NOT NULL,
  `fechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`idCompra`),
  KEY `estadoCompra` (`estadoCompra`),
  CONSTRAINT `tblcompra_ibfk_1` FOREIGN KEY (`estadoCompra`) REFERENCES `catestadocompra` (`idEstadoCompra`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblcompra` VALUES (1,1,6,"","2022-10-19","2022-10-19 21:13:29"),
(2,2,6,"","2022-10-19","2022-10-19 21:15:50"),
(3,4,6,"Producto en buenas condiciones","2022-10-19","2022-10-19 21:33:27"),
(4,5,6,"Medicamentos completos","2022-10-20","2022-10-20 09:42:13"),
(5,7,6,"Sin comentarios","2022-10-31","2022-10-31 16:49:28");


DROP TABLE IF EXISTS `tblconstancia`;

CREATE TABLE `tblconstancia` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `CodDiagnostico` int(11) NOT NULL,
  `Razon` varchar(200) DEFAULT NULL,
  `Fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `HoraEntrada` datetime DEFAULT NULL,
  `HoraSalida` datetime DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodDiagnostico` (`CodDiagnostico`),
  CONSTRAINT `tblconstancia_ibfk_1` FOREIGN KEY (`CodDiagnostico`) REFERENCES `tbldiagnosticoconsulta` (`Codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblconsulta`;

CREATE TABLE `tblconsulta` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `CodMedico` int(11) NOT NULL,
  `IdCita` int(11) DEFAULT NULL,
  `CodPaciente` int(11) NOT NULL,
  `CodConsultorio` tinyint(4) NOT NULL,
  `Estado` tinyint(4) NOT NULL,
  `FechaYHora` datetime NOT NULL,
  `FhInicio` datetime DEFAULT NULL,
  `FhFinal` datetime DEFAULT NULL,
  `MotivoConsulta` varchar(250) DEFAULT NULL,
  `RegistradoPor` int(11) NOT NULL,
  `idServicio` int(11) NOT NULL,
  `NotasConsulta` varchar(255) DEFAULT NULL,
  `MotivoRevertida` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodMedico` (`CodMedico`),
  KEY `CodPaciente` (`CodPaciente`),
  KEY `CodConsultorio` (`CodConsultorio`),
  KEY `Estado` (`Estado`),
  KEY `RegistradoPor` (`RegistradoPor`),
  KEY `idServicio` (`idServicio`),
  CONSTRAINT `tblconsulta_ibfk_1` FOREIGN KEY (`CodMedico`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblconsulta_ibfk_2` FOREIGN KEY (`CodPaciente`) REFERENCES `tblpaciente` (`CodigoP`),
  CONSTRAINT `tblconsulta_ibfk_3` FOREIGN KEY (`CodConsultorio`) REFERENCES `catconsultorio` (`ID`),
  CONSTRAINT `tblconsulta_ibfk_4` FOREIGN KEY (`Estado`) REFERENCES `catestadoconsulta` (`ID`),
  CONSTRAINT `tblconsulta_ibfk_5` FOREIGN KEY (`RegistradoPor`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblconsulta_ibfk_6` FOREIGN KEY (`idServicio`) REFERENCES `tblserviciosbrindados` (`idServiciosBrindados`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblconsulta` VALUES (1,3,"0",1,1,5,"2022-10-13 13:19:18","2022-10-13 13:20:07",NULL,"Examen de arquitectura",4,1,"Está bien",NULL),
(2,3,"0",2,1,5,"2022-10-13 13:22:49","2022-10-13 13:23:10",NULL,"Ayudenlo",4,2,"Ayuda xd",NULL),
(7,3,"0",5,1,5,"2022-10-19 19:30:15","2022-10-19 19:32:51",NULL,"Paciente presenta fiebre",4,7,"Paciente, en efecto presenta calentura y parece que tiene dengue",NULL),
(8,3,"0",5,1,5,"2022-10-20 09:15:10","2022-10-20 09:17:59",NULL,"Tiene tos",4,9,"bla blab la bla",NULL),
(9,3,"0",5,1,5,"2022-10-20 11:27:30","2022-10-20 11:28:41",NULL,"Esta enfermo",4,12,"El paciente esta enfermo tiene fiebre",NULL),
(10,3,"0",6,1,5,"2022-10-31 16:30:13","2022-10-31 16:35:35",NULL,"Se siente mal del estomago",4,13,"El paciente presenta sintomas de dengue.",NULL);


DROP TABLE IF EXISTS `tbldetallereceta`;

CREATE TABLE `tbldetallereceta` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `Medicamento` int(11) DEFAULT NULL,
  `Dosis` varchar(50) DEFAULT NULL,
  `Frecuencia` varchar(40) DEFAULT NULL,
  `CodReceta` int(11) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `Medicamento` (`Medicamento`),
  KEY `CodReceta` (`CodReceta`),
  CONSTRAINT `tbldetallereceta_ibfk_1` FOREIGN KEY (`Medicamento`) REFERENCES `catmedicamentos` (`Codigo`),
  CONSTRAINT `tbldetallereceta_ibfk_2` FOREIGN KEY (`CodReceta`) REFERENCES `tblrecetamedicamentos` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbldetallereceta` VALUES (1,3,10,8,1),
(2,3,5,8,2),
(3,3,5,12,3);


DROP TABLE IF EXISTS `tbldetallesdecita`;

CREATE TABLE `tbldetallesdecita` (
  `IDDetallecita` int(11) NOT NULL AUTO_INCREMENT,
  `IdCita` int(11) NOT NULL,
  `HoraInicio` time NOT NULL,
  `HoraFin` time DEFAULT NULL,
  `IdConsultorio` tinyint(4) DEFAULT NULL,
  `CodDoctor` int(11) DEFAULT NULL,
  `Estado` tinyint(4) NOT NULL,
  PRIMARY KEY (`IDDetallecita`),
  KEY `IdCita` (`IdCita`),
  KEY `IdConsultorio` (`IdConsultorio`),
  KEY `CodDoctor` (`CodDoctor`),
  KEY `Estado` (`Estado`),
  CONSTRAINT `tbldetallesdecita_ibfk_1` FOREIGN KEY (`IdCita`) REFERENCES `tblcita` (`IDCita`),
  CONSTRAINT `tbldetallesdecita_ibfk_2` FOREIGN KEY (`IdConsultorio`) REFERENCES `catconsultorio` (`ID`),
  CONSTRAINT `tbldetallesdecita_ibfk_3` FOREIGN KEY (`CodDoctor`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tbldetallesdecita_ibfk_4` FOREIGN KEY (`Estado`) REFERENCES `catestadocita` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tbldetalleventafarmacia`;

CREATE TABLE `tbldetalleventafarmacia` (
  `idDetalleVentaFarmacia` int(11) NOT NULL AUTO_INCREMENT,
  `ventaFarmacia` int(11) NOT NULL,
  `detalleRecetaMedica` int(11) NOT NULL,
  `cantidadVendida` int(11) NOT NULL,
  `fechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`idDetalleVentaFarmacia`),
  KEY `ventaFarmacia` (`ventaFarmacia`),
  KEY `detalleRecetaMedica` (`detalleRecetaMedica`),
  CONSTRAINT `tbldetalleventafarmacia_ibfk_1` FOREIGN KEY (`ventaFarmacia`) REFERENCES `tblventafarmacia` (`idVentaFarmacia`),
  CONSTRAINT `tbldetalleventafarmacia_ibfk_2` FOREIGN KEY (`detalleRecetaMedica`) REFERENCES `tbldetallereceta` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbldetalleventafarmacia` VALUES (1,1,1,10,"2022-10-19 21:30:19"),
(2,2,2,5,"2022-10-20 09:21:55"),
(3,3,1,10,"2022-10-20 10:23:39"),
(4,4,3,5,"2022-10-31 16:42:37");


DROP TABLE IF EXISTS `tbldetfactconsulta`;

CREATE TABLE `tbldetfactconsulta` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `CodConsulta` int(11) NOT NULL,
  `CodFactura` int(11) NOT NULL,
  `Precio` decimal(10,0) DEFAULT NULL,
  `Descuento` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodConsulta` (`CodConsulta`),
  KEY `CodFactura` (`CodFactura`),
  CONSTRAINT `tbldetfactconsulta_ibfk_1` FOREIGN KEY (`CodConsulta`) REFERENCES `tblconsulta` (`Codigo`),
  CONSTRAINT `tbldetfactconsulta_ibfk_2` FOREIGN KEY (`CodFactura`) REFERENCES `tblfactura` (`Codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tbldetfactexamen`;

CREATE TABLE `tbldetfactexamen` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `CodExamen` int(11) NOT NULL,
  `Precio` decimal(10,0) DEFAULT NULL,
  `Descuento` decimal(10,0) DEFAULT NULL,
  `CodFactura` int(11) NOT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodExamen` (`CodExamen`),
  KEY `CodFactura` (`CodFactura`),
  CONSTRAINT `tbldetfactexamen_ibfk_1` FOREIGN KEY (`CodExamen`) REFERENCES `tblexamen` (`Codigo`),
  CONSTRAINT `tbldetfactexamen_ibfk_2` FOREIGN KEY (`CodFactura`) REFERENCES `tblfactura` (`Codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tbldetpagoservicios`;

CREATE TABLE `tbldetpagoservicios` (
  `idDetPago` int(11) NOT NULL AUTO_INCREMENT,
  `ServicioBrindado` int(11) NOT NULL,
  `Monto` decimal(10,2) NOT NULL,
  `RebajaPago` decimal(10,2) NOT NULL,
  `metodoDePago` int(11) NOT NULL,
  `NumeroRecibo` int(11) DEFAULT NULL,
  PRIMARY KEY (`idDetPago`),
  KEY `ServicioBrindado` (`ServicioBrindado`),
  KEY `metodoDePago` (`metodoDePago`),
  KEY `NumeroRecibo` (`NumeroRecibo`),
  CONSTRAINT `tbldetpagoservicios_ibfk_1` FOREIGN KEY (`ServicioBrindado`) REFERENCES `tblserviciosbrindados` (`idServiciosBrindados`),
  CONSTRAINT `tbldetpagoservicios_ibfk_2` FOREIGN KEY (`metodoDePago`) REFERENCES `catmetodosdepago` (`idMetodoPago`),
  CONSTRAINT `tbldetpagoservicios_ibfk_3` FOREIGN KEY (`NumeroRecibo`) REFERENCES `tblrecibosventa` (`idRecibo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbldetpagoservicios` VALUES (1,1,"300.00","0.00",1,1),
(2,7,"300.00","0.00",1,2),
(3,8,"400.00","0.00",1,3),
(4,9,"300.00","0.00",1,3),
(5,10,"200.00","0.00",1,3),
(6,11,"400.00","0.00",1,4),
(7,12,"150.00","0.00",1,5),
(8,13,"300.00","0.00",1,6),
(9,14,"200.00","0.00",1,6);


DROP TABLE IF EXISTS `tbldetsolicitudcompra`;

CREATE TABLE `tbldetsolicitudcompra` (
  `idDetSolicitudCompra` int(11) NOT NULL AUTO_INCREMENT,
  `solicitudCompra` int(11) NOT NULL,
  `medicamento` int(11) NOT NULL,
  `proveedor` int(11) NOT NULL,
  `laboratorio` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `costo` double NOT NULL,
  PRIMARY KEY (`idDetSolicitudCompra`),
  KEY `solicitudCompra` (`solicitudCompra`),
  KEY `medicamento` (`medicamento`),
  KEY `proveedor` (`proveedor`),
  KEY `laboratorio` (`laboratorio`),
  CONSTRAINT `tbldetsolicitudcompra_ibfk_1` FOREIGN KEY (`solicitudCompra`) REFERENCES `tblsolicitudcompra` (`idSolicitudCompra`),
  CONSTRAINT `tbldetsolicitudcompra_ibfk_2` FOREIGN KEY (`medicamento`) REFERENCES `catmedicamentos` (`Codigo`),
  CONSTRAINT `tbldetsolicitudcompra_ibfk_3` FOREIGN KEY (`proveedor`) REFERENCES `tblproveedores` (`idProveedor`),
  CONSTRAINT `tbldetsolicitudcompra_ibfk_4` FOREIGN KEY (`laboratorio`) REFERENCES `catlaboratorio` (`idLaboratorio`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbldetsolicitudcompra` VALUES (1,1,3,1,1,90,5),
(2,2,2,1,1,60,12),
(3,2,4,1,2,20,17),
(5,4,1,4,1,100,10),
(6,5,1,4,1,10,10),
(7,5,3,4,2,5,7),
(8,6,4,1,2,50,17),
(9,7,5,4,1,20,20);


DROP TABLE IF EXISTS `tbldiagnosticoconsulta`;

CREATE TABLE `tbldiagnosticoconsulta` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `Descripcion` varchar(255) NOT NULL,
  `IdEnfermedad` tinyint(4) NOT NULL,
  `CodConsulta` int(11) NOT NULL,
  `Nota` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodConsulta` (`CodConsulta`),
  KEY `IdEnfermedad` (`IdEnfermedad`),
  CONSTRAINT `tbldiagnosticoconsulta_ibfk_1` FOREIGN KEY (`CodConsulta`) REFERENCES `tblconsulta` (`Codigo`),
  CONSTRAINT `tbldiagnosticoconsulta_ibfk_2` FOREIGN KEY (`IdEnfermedad`) REFERENCES `catenfermedades` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbldiagnosticoconsulta` VALUES (1,"Necesita reposo",3,1,"Ayudenlo"),
(2,"El paciente vino con temperatura alta",2,7,"Se recomienda tomar suero y descanso"),
(3,"El brother se está muriendo",4,8,"Ayudenlo"),
(4,"diagnosticado",10,9,"todo bien"),
(5,"Presenta los sintoma dados",10,10,"Siuuuuu");


DROP TABLE IF EXISTS `tblempleado`;

CREATE TABLE `tblempleado` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `INSS` varchar(9) NOT NULL,
  `FechaIngreso` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `CodPersona` int(11) NOT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodPersona` (`CodPersona`),
  CONSTRAINT `tblempleado_ibfk_1` FOREIGN KEY (`CodPersona`) REFERENCES `tblpersona` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblempleado` VALUES (1,111111111,"2022-09-30 00:00:00",1),
(2,222222222,"2022-09-30 00:00:00",2),
(3,333333333,"2022-09-30 00:00:00",3),
(4,444444444,"2022-09-30 00:00:00",4),
(5,555555555,"2022-09-30 00:00:00",5),
(6,666666666,"2022-09-30 00:00:00",6),
(7,777777777,"2022-09-30 00:00:00",7),
(8,888888888,"2022-09-30 00:00:00",8),
(9,877765123,"2022-10-20 10:34:23",11),
(10,763172312,"2022-10-31 16:56:45",13);


DROP TABLE IF EXISTS `tblespecialidad`;

CREATE TABLE `tblespecialidad` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CodDoctor` int(11) NOT NULL,
  `IDEspecialidad` tinyint(4) NOT NULL,
  `FechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `CodDoctor` (`CodDoctor`),
  KEY `IDEspecialidad` (`IDEspecialidad`),
  CONSTRAINT `tblespecialidad_ibfk_1` FOREIGN KEY (`CodDoctor`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblespecialidad_ibfk_2` FOREIGN KEY (`IDEspecialidad`) REFERENCES `catespecialidades` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblestudioacademico`;

CREATE TABLE `tblestudioacademico` (
  `IDEstudioAcademico` int(11) NOT NULL AUTO_INCREMENT,
  `CodEmpleado` int(11) NOT NULL,
  `NombreEstudio` varchar(100) NOT NULL,
  `TipoEstudio` tinyint(4) NOT NULL,
  `Institucion` varchar(60) NOT NULL,
  `InicioEstudio` date NOT NULL,
  `FinEstudio` date NOT NULL,
  `Diploma` blob DEFAULT NULL,
  PRIMARY KEY (`IDEstudioAcademico`),
  KEY `CodEmpleado` (`CodEmpleado`),
  KEY `TipoEstudio` (`TipoEstudio`),
  CONSTRAINT `tblestudioacademico_ibfk_1` FOREIGN KEY (`CodEmpleado`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblestudioacademico_ibfk_2` FOREIGN KEY (`TipoEstudio`) REFERENCES `catnivelacademico` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblexamen`;

CREATE TABLE `tblexamen` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `RecetaPrevia` int(11) DEFAULT NULL,
  `CodPaciente` int(11) NOT NULL,
  `SalaMedica` tinyint(4) DEFAULT NULL,
  `MaquinariaMedica` tinyint(4) DEFAULT NULL,
  `EmpleadoRealizacion` int(11) DEFAULT NULL,
  `FechaYHora` datetime DEFAULT NULL,
  `idServicio` int(11) NOT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `RecetaPrevia` (`RecetaPrevia`),
  KEY `CodPaciente` (`CodPaciente`),
  KEY `SalaMedica` (`SalaMedica`),
  KEY `EmpleadoRealizacion` (`EmpleadoRealizacion`),
  KEY `idServicio` (`idServicio`),
  CONSTRAINT `tblexamen_ibfk_1` FOREIGN KEY (`RecetaPrevia`) REFERENCES `tblrecetaexamen` (`Codigo`),
  CONSTRAINT `tblexamen_ibfk_2` FOREIGN KEY (`CodPaciente`) REFERENCES `tblpaciente` (`CodigoP`),
  CONSTRAINT `tblexamen_ibfk_3` FOREIGN KEY (`SalaMedica`) REFERENCES `catsalaexamen` (`ID`),
  CONSTRAINT `tblexamen_ibfk_4` FOREIGN KEY (`EmpleadoRealizacion`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblexamen_ibfk_5` FOREIGN KEY (`idServicio`) REFERENCES `tblserviciosbrindados` (`idServiciosBrindados`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblfactura`;

CREATE TABLE `tblfactura` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `MetodoDePago` tinyint(4) DEFAULT NULL,
  `Descuento` decimal(10,0) DEFAULT NULL,
  `EmpleadoCaja` int(11) DEFAULT NULL,
  `PagadoCon` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`Codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblfamiliares`;

CREATE TABLE `tblfamiliares` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CodPersona` int(11) NOT NULL,
  `ContactoEmergencia` tinyint(4) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `CodPersona` (`CodPersona`),
  CONSTRAINT `tblfamiliares_ibfk_1` FOREIGN KEY (`CodPersona`) REFERENCES `tblpersona` (`Codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblhistorialacademico`;

CREATE TABLE `tblhistorialacademico` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CodPaciente` int(11) NOT NULL,
  `Nivel_academico` tinyint(4) NOT NULL,
  `FechaObtencion` date NOT NULL,
  `FechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CodPaciente` (`CodPaciente`),
  KEY `Nivel_academico` (`Nivel_academico`),
  KEY `Estado` (`Estado`),
  CONSTRAINT `tblhistorialacademico_ibfk_1` FOREIGN KEY (`CodPaciente`) REFERENCES `tblpaciente` (`CodigoP`),
  CONSTRAINT `tblhistorialacademico_ibfk_2` FOREIGN KEY (`Nivel_academico`) REFERENCES `catnivelacademico` (`ID`),
  CONSTRAINT `tblhistorialacademico_ibfk_3` FOREIGN KEY (`Estado`) REFERENCES `catestado` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblhistorialcargos`;

CREATE TABLE `tblhistorialcargos` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CodEmpleado` int(11) NOT NULL,
  `IdCargo` tinyint(4) NOT NULL,
  `FechaAsignacion` date NOT NULL,
  `Salario` varchar(8) DEFAULT NULL,
  `Estado` tinyint(4) DEFAULT NULL,
  `RegistradoPor` int(11) NOT NULL,
  `AprobadoPor` int(11) DEFAULT NULL,
  `FechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `CodEmpleado` (`CodEmpleado`),
  KEY `IdCargo` (`IdCargo`),
  KEY `Estado` (`Estado`),
  KEY `RegistradoPor` (`RegistradoPor`),
  KEY `AprobadoPor` (`AprobadoPor`),
  CONSTRAINT `tblhistorialcargos_ibfk_1` FOREIGN KEY (`CodEmpleado`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblhistorialcargos_ibfk_2` FOREIGN KEY (`IdCargo`) REFERENCES `catcargos` (`ID`),
  CONSTRAINT `tblhistorialcargos_ibfk_3` FOREIGN KEY (`Estado`) REFERENCES `catestado` (`ID`),
  CONSTRAINT `tblhistorialcargos_ibfk_4` FOREIGN KEY (`RegistradoPor`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblhistorialcargos_ibfk_5` FOREIGN KEY (`AprobadoPor`) REFERENCES `tblempleado` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblhistorialcargos` VALUES (1,1,7,"2022-09-30",30000,1,1,1,"2022-09-30 00:00:00"),
(2,2,5,"2022-09-30",50000,1,1,1,"2022-09-30 00:00:00"),
(3,3,2,"2022-09-30",25000,1,1,2,"2022-09-30 00:00:00"),
(4,4,3,"2022-09-30",12000,1,1,2,"2022-09-30 00:00:00"),
(5,5,4,"2022-09-30",16000,1,1,2,"2022-09-30 00:00:00"),
(6,6,1,"2022-09-30",15000,1,1,2,"2022-09-30 00:00:00"),
(7,7,6,"2022-09-30",28000,1,1,2,"2022-09-30 00:00:00"),
(8,8,8,"2022-09-30",40000,1,1,2,"2022-09-30 00:00:00"),
(9,9,2,"2022-10-20",6000,1,2,2,"2022-10-20 10:38:47"),
(10,10,1,"2022-10-31",8000,1,2,2,"2022-10-31 16:58:36");


DROP TABLE IF EXISTS `tbllotemedicamento`;

CREATE TABLE `tbllotemedicamento` (
  `idLote` int(11) NOT NULL AUTO_INCREMENT,
  `medicamento` int(11) NOT NULL,
  `fechaVence` date NOT NULL,
  `cantidadEnlote` int(11) NOT NULL,
  `fechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`idLote`),
  KEY `medicamento` (`medicamento`),
  CONSTRAINT `tbllotemedicamento_ibfk_1` FOREIGN KEY (`medicamento`) REFERENCES `catmedicamentos` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbllotemedicamento` VALUES (1,3,"2023-02-28",60,"2022-10-31 16:42:37"),
(2,4,"2023-02-13",20,"2022-10-19 21:16:10"),
(3,2,"2023-12-12",60,"2022-10-19 21:16:28"),
(4,1,"2022-12-28",50,"2022-10-20 09:43:28"),
(5,1,"2023-03-16",50,"2022-10-20 09:43:51"),
(6,3,"2023-01-26",3,"2022-10-31 16:51:09"),
(7,3,"2023-02-24",2,"2022-10-31 16:51:59");


DROP TABLE IF EXISTS `tblmaquinariamedica`;

CREATE TABLE `tblmaquinariamedica` (
  `Codigo` tinyint(4) NOT NULL,
  `tipoMaquina` tinyint(4) DEFAULT NULL,
  `marca` varchar(20) DEFAULT NULL,
  `modelo` varchar(20) DEFAULT NULL,
  `numeroDeSerie` varchar(20) DEFAULT NULL,
  `Fecha_de_compra` date DEFAULT NULL,
  `ubicacion` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `tipoMaquina` (`tipoMaquina`),
  KEY `ubicacion` (`ubicacion`),
  CONSTRAINT `tblmaquinariamedica_ibfk_1` FOREIGN KEY (`tipoMaquina`) REFERENCES `catmaquinaria` (`ID`),
  CONSTRAINT `tblmaquinariamedica_ibfk_2` FOREIGN KEY (`ubicacion`) REFERENCES `catsalaexamen` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblmedicamentoprecio`;

CREATE TABLE `tblmedicamentoprecio` (
  `idMedicamentoPrecio` int(11) NOT NULL AUTO_INCREMENT,
  `medicamento` int(11) NOT NULL,
  `precioVenta` double NOT NULL,
  PRIMARY KEY (`idMedicamentoPrecio`),
  KEY `medicamento` (`medicamento`),
  CONSTRAINT `tblmedicamentoprecio_ibfk_1` FOREIGN KEY (`medicamento`) REFERENCES `catmedicamentos` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblmedicamentoprecio` VALUES (1,1,20),
(2,2,30),
(3,3,40),
(4,4,50),
(5,5,60);


DROP TABLE IF EXISTS `tblmedicamentoproveedor`;

CREATE TABLE `tblmedicamentoproveedor` (
  `idmedicamentoproveedor` int(11) NOT NULL AUTO_INCREMENT,
  `medicamento` int(11) NOT NULL,
  `proveedor` int(11) NOT NULL,
  `laboratorio` int(11) NOT NULL,
  `precioMedicamento` double NOT NULL,
  PRIMARY KEY (`idmedicamentoproveedor`),
  KEY `medicamento` (`medicamento`),
  KEY `proveedor` (`proveedor`),
  KEY `laboratorio` (`laboratorio`),
  CONSTRAINT `tblmedicamentoproveedor_ibfk_1` FOREIGN KEY (`medicamento`) REFERENCES `catmedicamentos` (`Codigo`),
  CONSTRAINT `tblmedicamentoproveedor_ibfk_2` FOREIGN KEY (`proveedor`) REFERENCES `tblproveedores` (`idProveedor`),
  CONSTRAINT `tblmedicamentoproveedor_ibfk_3` FOREIGN KEY (`laboratorio`) REFERENCES `catlaboratorio` (`idLaboratorio`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblmedicamentoproveedor` VALUES (1,1,2,1,10),
(2,1,3,1,10),
(3,1,4,1,10),
(4,1,1,2,15),
(5,1,2,2,15),
(6,1,3,3,8),
(7,1,4,3,8),
(8,2,1,1,12),
(9,2,2,1,12),
(10,2,1,2,11),
(11,2,3,2,11),
(12,2,4,2,11),
(13,2,4,3,14),
(14,3,1,1,5),
(15,3,2,1,5),
(16,3,1,2,7),
(17,3,2,2,7),
(18,3,3,2,7),
(19,3,4,2,7),
(20,3,1,3,6),
(21,3,3,3,6),
(22,3,4,3,6),
(23,4,4,1,15),
(24,4,1,2,17),
(25,4,3,2,17),
(26,5,1,1,20),
(27,5,4,1,20),
(28,5,1,2,25),
(29,5,2,2,25),
(30,5,3,3,18),
(31,5,4,3,18);


DROP TABLE IF EXISTS `tblocupacionpacientes`;

CREATE TABLE `tblocupacionpacientes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CodPaciente` int(11) NOT NULL,
  `Nombre` varchar(60) NOT NULL,
  `Empresa` varchar(60) DEFAULT NULL,
  `Telefono` varchar(8) DEFAULT NULL,
  `Referencia` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CodPaciente` (`CodPaciente`),
  CONSTRAINT `tblocupacionpacientes_ibfk_1` FOREIGN KEY (`CodPaciente`) REFERENCES `tblpaciente` (`CodigoP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblpaciente`;

CREATE TABLE `tblpaciente` (
  `CodigoP` int(11) NOT NULL AUTO_INCREMENT,
  `CodExpediente` varchar(10) NOT NULL,
  `INSS` int(11) NOT NULL,
  `GrupoSanguineo` tinyint(4) NOT NULL,
  `CodPersona` int(11) NOT NULL,
  PRIMARY KEY (`CodigoP`),
  KEY `CodPersona` (`CodPersona`),
  KEY `GrupoSanguineo` (`GrupoSanguineo`),
  CONSTRAINT `tblpaciente_ibfk_1` FOREIGN KEY (`CodPersona`) REFERENCES `tblpersona` (`Codigo`),
  CONSTRAINT `tblpaciente_ibfk_2` FOREIGN KEY (`GrupoSanguineo`) REFERENCES `catgruposanguineo` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblpaciente` VALUES (1,90,761273212,2,9),
(2,20,127132731,2,2),
(5,100,188121211,2,10),
(6,120,213232323,5,12);


DROP TABLE IF EXISTS `tblpersona`;

CREATE TABLE `tblpersona` (
  `Codigo` int(11) NOT NULL,
  `Cedula` varchar(16) NOT NULL,
  `Nombres` varchar(60) NOT NULL,
  `Apellidos` varchar(60) NOT NULL,
  `Fecha_de_nacimiento` date NOT NULL,
  `Genero` tinyint(4) NOT NULL,
  `Estado_civil` tinyint(4) DEFAULT NULL,
  `Direccion` varchar(100) DEFAULT NULL,
  `Telefono` varchar(13) DEFAULT NULL,
  `Email` varchar(40) DEFAULT NULL,
  `Estado` tinyint(4) NOT NULL,
  `Fecha_registro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Codigo`),
  KEY `Genero` (`Genero`),
  KEY `Estado_civil` (`Estado_civil`),
  KEY `Estado` (`Estado`),
  CONSTRAINT `tblpersona_ibfk_1` FOREIGN KEY (`Genero`) REFERENCES `catgenero` (`ID`),
  CONSTRAINT `tblpersona_ibfk_2` FOREIGN KEY (`Estado_civil`) REFERENCES `catestadocivil` (`ID`),
  CONSTRAINT `tblpersona_ibfk_3` FOREIGN KEY (`Estado`) REFERENCES `catestado` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblpersona` VALUES (1,"001-091001-1001k","Steven David","Espinoza Ulloa","2001-10-09",1,1,"Bo.Jorge Dimitrov. Del colegio primero de junio 20 vrs al este MI.",88145268,"espinozasteven659@gmail.com",1,"2022-09-30 00:00:00"),
(2,"001-091001-1001J","Luis Manuel","Matus Ramos","2000-10-09",1,1,"Bo.Jorge Dimitrov. Del colegio primero de junio 20 vrs al este MI.",77024746,"espinozasteven658@gmail.com",1,"2022-09-30 00:00:00"),
(3,"001-091001-1001A","Enrique Jose","Muños Avellan","2000-10-18",1,1,"Bo.Jorge Dimitrov. Del colegio primero de junio 20 vrs al este MI.",78514269,"avellanenrique@gmail.com",1,"2022-09-30 00:00:00"),
(4,"001-091001-1001B","Marcos Antonio","Duartes","2000-10-18",1,1,"Bo.Jorge Dimitrov. Del colegio primero de junio 20 vrs al este MI.",79451236,"duartesmarcos@gmail.com",1,"2022-09-30 00:00:00"),
(5,"001-091001-1001C","Manuel Salvador","Espinoza Quiroz","2000-10-18",1,1,"Bo.Jorge Dimitrov. Del colegio primero de junio 20 vrs al este MI.",85621436,"espinozamanuel@gmail.com",1,"2022-09-30 00:00:00"),
(6,"001-091001-1001D","Stayci yahoska","Ramirez Zeledon","2000-10-18",2,1,"Bo.Jorge Dimitrov. Del colegio primero de junio 20 vrs al este MI.",81247569,"zeledonstayci@gmail.com",1,"2022-09-30 00:00:00"),
(7,"001-091001-1001E","Felipe David","Treminio Moreno","2000-10-18",1,1,"Bo.Jorge Dimitrov. Del colegio primero de junio 20 vrs al este MI.",72157863,"morenofelipe@gmail.com",1,"2022-09-30 00:00:00"),
(8,"001-091001-1001F","Juan Pablo","Hernandez Quiroz","2001-10-09",1,1,"Bo.Jorge Dimitrov. Del colegio primero de junio 20 vrs al este MI.",88141463,"hernandezjuan@gmail.com",1,"2022-09-30 00:00:00"),
(9,"281-120700-1000V","Pedro Joaquín","Gutierrez","2000-12-12",1,1,"Managua",17263127312,"sobreton@gmail.com",1,"2022-10-13 13:18:45"),
(10,"281-121299-1000V","Ejemplo","Feria","1999-12-12",1,1,"Managua, residencial el dorado",88121218,"ejemploferia@gmail.com",1,"2022-10-19 19:28:56"),
(11,"561-181009-1009W","Reynaldo","Martinez","2000-07-05",1,1,"Managua",87996658,"correo@gmail.com",1,"2022-10-20 10:34:23"),
(12,"001-091001-1002K","Paciente","Prueba","1999-11-16",1,1,"Managua",88145267,"asdasd@gmail.com",1,"2022-10-31 16:27:41"),
(13,"191-111111-1111B","Empleado","Prueba","2001-02-23",1,1,"Managua",8718731231,"anusdfhafi@gmail.com",1,"2022-10-31 16:56:45");


DROP TABLE IF EXISTS `tblprivilegiosusuario`;

CREATE TABLE `tblprivilegiosusuario` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `CodUsuario` int(11) NOT NULL,
  `CodPrivilegio` int(11) NOT NULL,
  `CodigoSubModulo` int(11) NOT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodPrivilegio` (`CodPrivilegio`),
  KEY `CodUsuario` (`CodUsuario`),
  KEY `CodigoSubModulo` (`CodigoSubModulo`),
  CONSTRAINT `tblprivilegiosusuario_ibfk_1` FOREIGN KEY (`CodPrivilegio`) REFERENCES `catprivilegio` (`Codigo`),
  CONSTRAINT `tblprivilegiosusuario_ibfk_2` FOREIGN KEY (`CodUsuario`) REFERENCES `tblusuarios` (`Codigo`),
  CONSTRAINT `tblprivilegiosusuario_ibfk_3` FOREIGN KEY (`CodigoSubModulo`) REFERENCES `catsubmodulos` (`CodSubModulo`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblprivilegiosusuario` VALUES (1,1,1,2),
(2,1,2,2),
(3,1,3,2),
(4,1,1,3),
(5,1,2,3),
(6,1,3,3),
(7,1,1,6),
(8,1,2,6),
(9,1,3,6),
(10,1,1,4),
(11,1,2,4),
(12,1,3,4),
(13,1,1,5),
(14,1,2,5),
(15,1,3,5),
(16,1,1,7),
(17,1,2,7),
(18,1,3,7),
(19,1,1,21),
(20,1,2,21),
(21,1,3,21),
(22,1,1,24),
(23,1,2,24),
(24,1,1,23),
(25,1,2,23),
(26,2,1,2),
(27,2,2,2),
(28,2,3,2),
(29,2,1,3),
(30,2,2,3),
(31,2,3,3),
(32,2,1,6),
(33,2,2,6),
(34,2,3,6),
(35,2,1,4),
(36,2,2,4),
(37,2,3,4),
(38,2,1,5),
(39,2,2,5),
(40,2,3,5),
(41,2,1,7),
(42,2,2,7),
(43,2,3,7),
(44,2,2,8),
(45,2,1,21),
(46,2,2,21),
(47,2,3,21),
(48,2,2,24),
(49,3,2,12),
(50,3,3,12),
(51,3,2,8),
(52,3,2,1),
(53,3,1,13),
(54,3,2,13),
(55,3,3,13),
(56,3,1,14),
(57,3,2,14),
(58,3,3,14),
(59,3,1,15),
(60,3,2,15),
(61,3,1,16),
(62,3,2,16),
(63,3,1,17),
(64,3,2,17),
(65,3,2,18),
(66,3,2,19),
(67,4,1,22),
(68,4,2,22),
(69,4,3,22),
(70,4,2,12),
(71,4,3,12),
(72,4,1,8),
(73,4,2,8),
(74,4,3,8),
(75,4,1,1),
(76,4,2,1),
(77,4,3,1),
(78,5,2,12),
(79,5,2,8),
(80,5,2,18),
(81,5,2,19),
(82,5,1,28),
(83,5,2,28),
(84,6,2,12),
(85,6,1,13),
(86,6,2,13),
(87,6,3,13),
(88,6,2,8),
(89,6,2,22),
(90,7,1,18),
(91,7,2,18),
(92,7,3,18),
(93,7,1,19),
(94,7,2,19),
(95,7,2,8),
(96,8,1,25),
(97,8,2,25),
(98,8,1,24),
(99,8,2,24),
(100,8,1,23),
(101,8,2,23),
(102,9,2,1),
(103,9,2,8),
(104,9,2,12),
(105,9,3,12),
(106,9,2,12),
(107,9,2,13),
(108,9,1,13),
(109,9,3,13),
(110,9,2,13),
(111,9,2,14),
(112,9,1,14),
(113,9,3,14),
(114,9,2,14),
(115,9,2,15),
(116,9,1,15),
(117,9,3,15),
(118,9,2,15),
(119,9,2,16),
(120,9,1,16),
(121,9,3,16),
(122,9,2,16),
(123,9,2,17),
(124,9,1,17),
(125,9,3,17),
(126,9,2,17),
(127,9,2,18),
(128,9,2,19),
(129,10,2,3),
(130,10,1,3),
(131,10,3,3),
(132,10,2,3),
(133,10,2,8),
(134,10,1,8),
(135,10,3,8),
(136,10,2,8),
(137,10,2,22),
(138,10,1,22),
(139,10,3,22),
(140,10,2,22),
(141,10,2,12),
(142,10,3,12),
(143,10,2,12);


DROP TABLE IF EXISTS `tblproveedores`;

CREATE TABLE `tblproveedores` (
  `idProveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombreProveedor` varchar(100) NOT NULL,
  `telefonoProveedor` varchar(13) NOT NULL,
  `direccionProveedor` varchar(255) NOT NULL,
  `emailProveedor` varchar(60) NOT NULL,
  `ranking` int(11) NOT NULL,
  `tiempoEntrega` int(11) NOT NULL,
  `estadoProveedor` int(11) NOT NULL,
  `descripcionProveedor` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idProveedor`),
  KEY `estadoProveedor` (`estadoProveedor`),
  CONSTRAINT `tblproveedores_ibfk_1` FOREIGN KEY (`estadoProveedor`) REFERENCES `catestadocompra` (`idEstadoCompra`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblproveedores` VALUES (1,"Medicamentos.S.A",85746321,"Ciudad jardin","medicamentossa@gmail.com",3,5,1,""),
(2,"Pastillas.S.A",84365219,"Dorado","pastillassa@gmail.com",2,6,1,""),
(3,"SaludForever.S.A",86352469,"Ciudad sandino","saludforeversa@gmail.com",4,7,1,""),
(4,"BuenaVida",77456982,"Plaza españa","buenavidasa@gmail.com",5,4,1,"");


DROP TABLE IF EXISTS `tblrecetaexamen`;

CREATE TABLE `tblrecetaexamen` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `ConsultaPrevia` int(11) NOT NULL,
  `TipoExamen` tinyint(4) NOT NULL,
  `Motivo` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `TipoExamen` (`TipoExamen`),
  KEY `ConsultaPrevia` (`ConsultaPrevia`),
  CONSTRAINT `tblrecetaexamen_ibfk_1` FOREIGN KEY (`TipoExamen`) REFERENCES `catexamenesmedicos` (`ID`),
  CONSTRAINT `tblrecetaexamen_ibfk_2` FOREIGN KEY (`ConsultaPrevia`) REFERENCES `tblconsulta` (`Codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblrecetamedicamentos`;

CREATE TABLE `tblrecetamedicamentos` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `CodigoConsulta` int(11) NOT NULL,
  `FechaEmision` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`Codigo`),
  KEY `CodigoConsulta` (`CodigoConsulta`),
  CONSTRAINT `tblrecetamedicamentos_ibfk_1` FOREIGN KEY (`CodigoConsulta`) REFERENCES `tblconsulta` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblrecetamedicamentos` VALUES (1,7,"2022-10-19 19:34:29"),
(2,8,"2022-10-20 09:20:26"),
(3,10,"2022-10-31 16:38:22");


DROP TABLE IF EXISTS `tblrecibosventa`;

CREATE TABLE `tblrecibosventa` (
  `idRecibo` int(11) NOT NULL AUTO_INCREMENT,
  `Cliente` int(11) NOT NULL,
  `aperturaCaja` int(11) NOT NULL,
  `FyHRegistro` datetime NOT NULL,
  PRIMARY KEY (`idRecibo`),
  KEY `Cliente` (`Cliente`),
  KEY `aperturaCaja` (`aperturaCaja`),
  CONSTRAINT `tblrecibosventa_ibfk_1` FOREIGN KEY (`Cliente`) REFERENCES `tblclientes` (`idCliente`),
  CONSTRAINT `tblrecibosventa_ibfk_2` FOREIGN KEY (`aperturaCaja`) REFERENCES `tblaperturacaja` (`idApertura`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblrecibosventa` VALUES (1,1,23,"2022-10-13 14:06:43"),
(2,2,23,"2022-10-19 19:36:10"),
(3,2,23,"2022-10-20 09:23:11"),
(4,2,24,"2022-10-20 10:25:53"),
(5,2,24,"2022-10-20 11:31:16"),
(6,3,24,"2022-10-31 16:54:10");


DROP TABLE IF EXISTS `tblrelacionpersonafamiliar`;

CREATE TABLE `tblrelacionpersonafamiliar` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Codigo_Persona` int(11) NOT NULL,
  `Codigo_Familiar` int(11) NOT NULL,
  `ID_Parentesco` tinyint(4) NOT NULL,
  `Tutor` bit(1) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Codigo_Persona` (`Codigo_Persona`),
  KEY `Codigo_Familiar` (`Codigo_Familiar`),
  KEY `ID_Parentesco` (`ID_Parentesco`),
  CONSTRAINT `tblrelacionpersonafamiliar_ibfk_1` FOREIGN KEY (`Codigo_Persona`) REFERENCES `tblpersona` (`Codigo`),
  CONSTRAINT `tblrelacionpersonafamiliar_ibfk_2` FOREIGN KEY (`Codigo_Familiar`) REFERENCES `tblfamiliares` (`ID`),
  CONSTRAINT `tblrelacionpersonafamiliar_ibfk_3` FOREIGN KEY (`ID_Parentesco`) REFERENCES `catparentesco` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblresultado`;

CREATE TABLE `tblresultado` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `CodExamen` int(11) NOT NULL,
  `ArchivoResultado` text DEFAULT NULL,
  `FechaYHora` date DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodExamen` (`CodExamen`),
  CONSTRAINT `tblresultado_ibfk_1` FOREIGN KEY (`CodExamen`) REFERENCES `tblexamen` (`Codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tblserviciosbrindados`;

CREATE TABLE `tblserviciosbrindados` (
  `idServiciosBrindados` int(11) NOT NULL AUTO_INCREMENT,
  `tipoServicio` int(11) NOT NULL,
  `estadoServicio` int(11) NOT NULL,
  `MontoServicio` decimal(10,2) NOT NULL,
  `RebajaServicio` decimal(10,2) NOT NULL,
  `fechaYHora` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idServiciosBrindados`),
  KEY `tipoServicio` (`tipoServicio`),
  KEY `estadoServicio` (`estadoServicio`),
  CONSTRAINT `tblserviciosbrindados_ibfk_1` FOREIGN KEY (`tipoServicio`) REFERENCES `catservicios` (`idServicio`),
  CONSTRAINT `tblserviciosbrindados_ibfk_2` FOREIGN KEY (`estadoServicio`) REFERENCES `catestadoservicios` (`idEstadoServicio`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblserviciosbrindados` VALUES (1,2,3,"300.00","0.00","2022-10-13 13:19:18"),
(2,2,1,"300.00","0.00","2022-10-13 13:22:49"),
(3,2,1,"300.00","0.00","2022-10-15 19:08:47"),
(4,2,1,"300.00","0.00","2022-10-19 18:45:27"),
(5,2,1,"300.00","0.00","2022-10-19 19:02:29"),
(6,2,1,"300.00","0.00","2022-10-19 19:19:31"),
(7,2,3,"300.00","0.00","2022-10-19 19:30:15"),
(8,3,3,"400.00","0.00","2022-10-19 21:30:19"),
(9,2,3,"300.00","0.00","2022-10-20 09:15:10"),
(10,3,3,"200.00","0.00","2022-10-20 09:21:55"),
(11,3,3,"400.00","0.00","2022-10-20 10:23:39"),
(12,2,2,"300.00","0.00","2022-10-20 11:27:30"),
(13,2,3,"300.00","0.00","2022-10-31 16:30:13"),
(14,3,3,"200.00","0.00","2022-10-31 16:42:37");


DROP TABLE IF EXISTS `tblsesion`;

CREATE TABLE `tblsesion` (
  `idSesion` int(11) NOT NULL AUTO_INCREMENT,
  `CodUsuarioSesion` int(11) NOT NULL,
  `EstadoSesion` tinyint(4) NOT NULL,
  `tokenSesion` varchar(200) DEFAULT NULL,
  `FechayHoraSesion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`idSesion`),
  KEY `CodUsuarioSesion` (`CodUsuarioSesion`),
  KEY `EstadoSesion` (`EstadoSesion`),
  CONSTRAINT `tblsesion_ibfk_1` FOREIGN KEY (`CodUsuarioSesion`) REFERENCES `tblusuarios` (`Codigo`),
  CONSTRAINT `tblsesion_ibfk_2` FOREIGN KEY (`EstadoSesion`) REFERENCES `catestado` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=356 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblsesion` VALUES (1,1,1,NULL,"2022-09-30 14:51:59"),
(2,1,2,NULL,"2022-09-30 14:57:40"),
(3,1,1,NULL,"2022-10-02 17:03:29"),
(4,1,2,NULL,"2022-10-02 17:08:12"),
(5,4,1,NULL,"2022-10-02 17:49:33"),
(6,4,2,NULL,"2022-10-02 18:29:35"),
(7,4,1,NULL,"2022-10-05 13:05:07"),
(8,4,2,NULL,"2022-10-05 13:56:02"),
(9,3,1,NULL,"2022-10-05 13:56:05"),
(10,3,2,NULL,"2022-10-05 13:57:19"),
(11,4,1,NULL,"2022-10-05 13:57:24"),
(12,4,2,NULL,"2022-10-05 13:57:27"),
(13,3,1,NULL,"2022-10-05 13:57:30"),
(14,3,2,NULL,"2022-10-05 13:58:33"),
(15,1,1,NULL,"2022-10-05 13:58:36"),
(16,1,2,NULL,"2022-10-05 13:58:39"),
(17,4,1,NULL,"2022-10-05 13:58:44"),
(18,4,2,NULL,"2022-10-05 14:03:18"),
(19,1,1,NULL,"2022-10-08 13:40:59"),
(20,1,2,NULL,"2022-10-08 13:49:35"),
(21,5,1,NULL,"2022-10-08 13:49:40"),
(22,5,2,NULL,"2022-10-08 13:51:11"),
(23,2,1,NULL,"2022-10-08 13:51:15"),
(24,2,2,NULL,"2022-10-08 14:06:12"),
(25,1,1,NULL,"2022-10-08 14:06:15"),
(26,1,2,NULL,"2022-10-08 14:08:27"),
(27,8,1,NULL,"2022-10-08 14:08:30"),
(28,8,2,NULL,"2022-10-08 14:10:40"),
(29,1,1,NULL,"2022-10-08 14:10:43"),
(30,1,2,NULL,"2022-10-08 14:11:04"),
(31,2,1,NULL,"2022-10-08 14:11:09"),
(32,2,2,NULL,"2022-10-08 17:38:04"),
(33,4,1,NULL,"2022-10-08 17:38:10"),
(34,4,2,NULL,"2022-10-08 17:58:11"),
(35,2,1,NULL,"2022-10-13 12:45:13"),
(36,2,2,NULL,"2022-10-13 13:17:21"),
(37,3,1,NULL,"2022-10-13 13:17:26"),
(38,3,2,NULL,"2022-10-13 13:17:32"),
(39,4,1,NULL,"2022-10-13 13:17:40"),
(40,4,2,NULL,"2022-10-13 13:19:26"),
(41,3,1,NULL,"2022-10-13 13:19:31"),
(42,3,2,NULL,"2022-10-13 13:20:47"),
(43,2,1,NULL,"2022-10-13 13:20:50"),
(44,2,2,NULL,"2022-10-13 13:21:52"),
(45,4,1,NULL,"2022-10-13 13:21:59"),
(46,4,2,NULL,"2022-10-13 13:22:54"),
(47,3,1,NULL,"2022-10-13 13:22:57"),
(48,3,2,NULL,"2022-10-13 13:23:13"),
(49,2,1,NULL,"2022-10-13 13:23:20"),
(50,2,2,NULL,"2022-10-13 14:05:54"),
(51,5,1,NULL,"2022-10-13 14:06:02"),
(52,5,2,NULL,"2022-10-13 14:19:58"),
(53,2,1,NULL,"2022-10-13 14:20:04"),
(54,2,2,NULL,"2022-10-13 15:56:14"),
(55,2,1,NULL,"2022-10-13 16:18:39"),
(56,2,2,NULL,"2022-10-13 20:24:04"),
(57,2,1,NULL,"2022-10-14 12:00:03"),
(58,2,2,NULL,"2022-10-14 12:00:38"),
(59,2,1,NULL,"2022-10-14 13:39:46"),
(60,2,2,NULL,"2022-10-14 13:49:28"),
(61,3,1,NULL,"2022-10-14 13:49:32"),
(62,3,2,NULL,"2022-10-15 19:08:10"),
(63,4,1,NULL,"2022-10-15 19:08:18"),
(64,4,2,NULL,"2022-10-15 19:08:52"),
(65,3,1,NULL,"2022-10-15 19:08:57"),
(66,3,2,NULL,"2022-10-15 19:39:10"),
(67,4,1,NULL,"2022-10-15 19:39:18"),
(68,4,2,NULL,"2022-10-15 19:51:11"),
(69,5,1,NULL,"2022-10-15 20:01:16"),
(70,5,2,NULL,"2022-10-15 20:10:43"),
(71,1,1,NULL,"2022-10-15 20:10:49"),
(72,1,2,NULL,"2022-10-15 20:11:38"),
(73,1,1,NULL,"2022-10-15 20:11:39"),
(74,1,2,NULL,"2022-10-15 20:27:01"),
(75,2,1,NULL,"2022-10-15 20:27:07"),
(76,2,2,NULL,"2022-10-15 20:39:53"),
(77,2,1,NULL,"2022-10-18 13:56:58"),
(78,2,2,NULL,"2022-10-18 13:57:48"),
(79,8,1,NULL,"2022-10-18 13:57:54"),
(80,8,2,NULL,"2022-10-18 14:09:47"),
(81,2,1,NULL,"2022-10-18 14:09:53"),
(82,2,2,NULL,"2022-10-18 14:13:13"),
(83,6,1,NULL,"2022-10-18 14:13:28"),
(84,6,2,NULL,"2022-10-18 14:13:33"),
(85,8,1,NULL,"2022-10-18 14:13:40"),
(86,8,2,NULL,"2022-10-18 14:17:03"),
(87,8,1,NULL,"2022-10-19 12:50:08"),
(88,8,2,NULL,"2022-10-19 12:50:51"),
(89,1,1,NULL,"2022-10-19 12:52:48"),
(90,3,1,NULL,"2022-10-19 12:53:31"),
(91,3,2,NULL,"2022-10-19 12:54:09"),
(92,1,2,NULL,"2022-10-19 12:54:33"),
(93,3,1,NULL,"2022-10-19 12:54:40"),
(94,5,1,NULL,"2022-10-19 12:54:43"),
(95,5,2,NULL,"2022-10-19 12:55:43"),
(96,1,1,NULL,"2022-10-19 12:55:46"),
(97,3,2,NULL,"2022-10-19 13:11:02"),
(98,3,2,NULL,"2022-10-19 13:17:02"),
(99,3,1,NULL,"2022-10-19 13:17:44"),
(100,3,2,NULL,"2022-10-19 13:18:04"),
(101,3,1,NULL,"2022-10-19 13:18:55"),
(102,3,2,NULL,"2022-10-19 13:21:20"),
(103,8,1,NULL,"2022-10-19 13:21:51"),
(104,8,2,NULL,"2022-10-19 13:22:11"),
(105,8,2,NULL,"2022-10-19 13:24:49"),
(106,1,2,NULL,"2022-10-19 13:35:17"),
(107,1,1,NULL,"2022-10-19 14:11:16"),
(108,1,2,NULL,"2022-10-19 14:12:52"),
(109,3,1,NULL,"2022-10-19 15:12:29"),
(110,3,2,NULL,"2022-10-19 18:07:42"),
(111,4,1,NULL,"2022-10-19 18:43:46"),
(112,4,2,NULL,"2022-10-19 18:45:36"),
(113,6,1,NULL,"2022-10-19 18:45:42"),
(114,6,2,NULL,"2022-10-19 18:46:22"),
(115,4,1,NULL,"2022-10-19 18:46:45"),
(116,4,2,NULL,"2022-10-19 18:48:35"),
(117,2,1,NULL,"2022-10-19 18:48:44"),
(118,2,2,NULL,"2022-10-19 18:54:21"),
(119,4,1,NULL,"2022-10-19 18:54:28"),
(120,4,2,NULL,"2022-10-19 18:54:37"),
(121,2,1,NULL,"2022-10-19 18:54:42"),
(122,2,2,NULL,"2022-10-19 18:55:19"),
(123,2,1,NULL,"2022-10-19 18:55:22"),
(124,2,2,NULL,"2022-10-19 18:55:34"),
(125,2,1,NULL,"2022-10-19 18:55:37"),
(126,2,2,NULL,"2022-10-19 18:55:58"),
(127,2,1,NULL,"2022-10-19 18:56:00"),
(128,2,2,NULL,"2022-10-19 18:56:52"),
(129,2,1,NULL,"2022-10-19 18:56:53"),
(130,2,2,NULL,"2022-10-19 18:57:03"),
(131,4,1,NULL,"2022-10-19 18:58:23"),
(132,4,2,NULL,"2022-10-19 19:02:45"),
(133,6,1,NULL,"2022-10-19 19:02:52"),
(134,6,2,NULL,"2022-10-19 19:12:50"),
(135,4,1,NULL,"2022-10-19 19:16:30"),
(136,4,2,NULL,"2022-10-19 19:20:05"),
(137,6,1,NULL,"2022-10-19 19:20:13"),
(138,6,2,NULL,"2022-10-19 19:22:28"),
(139,4,1,NULL,"2022-10-19 19:27:51"),
(140,4,2,NULL,"2022-10-19 19:30:30"),
(141,6,1,NULL,"2022-10-19 19:30:36"),
(142,6,2,NULL,"2022-10-19 19:31:13"),
(143,3,1,NULL,"2022-10-19 19:31:18"),
(144,3,2,NULL,"2022-10-19 19:35:11"),
(145,5,1,NULL,"2022-10-19 19:35:17"),
(146,5,2,NULL,"2022-10-19 19:36:34"),
(147,8,1,NULL,"2022-10-19 19:36:43"),
(148,8,2,NULL,"2022-10-19 19:38:27"),
(149,3,1,NULL,"2022-10-19 19:38:30"),
(150,3,2,NULL,"2022-10-19 21:09:23"),
(151,8,1,NULL,"2022-10-19 21:10:05"),
(152,8,2,NULL,"2022-10-19 21:11:59"),
(153,1,1,NULL,"2022-10-19 21:12:04"),
(154,1,2,NULL,"2022-10-19 21:12:16"),
(155,8,1,NULL,"2022-10-19 21:12:22"),
(156,8,2,NULL,"2022-10-19 21:14:04"),
(157,2,1,NULL,"2022-10-19 21:14:08"),
(158,2,2,NULL,"2022-10-19 21:14:31"),
(159,2,1,NULL,"2022-10-19 21:14:32"),
(160,2,2,NULL,"2022-10-19 21:15:21"),
(161,8,1,NULL,"2022-10-19 21:15:27"),
(162,8,2,NULL,"2022-10-19 21:17:25"),
(163,4,1,NULL,"2022-10-19 21:17:30"),
(164,4,2,NULL,"2022-10-19 21:17:48"),
(165,4,1,NULL,"2022-10-19 21:17:51"),
(166,4,2,NULL,"2022-10-19 21:26:34"),
(167,2,1,NULL,"2022-10-19 21:26:37"),
(168,2,2,NULL,"2022-10-19 21:27:40"),
(169,3,1,NULL,"2022-10-19 21:27:43"),
(170,3,2,NULL,"2022-10-19 21:28:31"),
(171,1,1,NULL,"2022-10-19 21:28:34"),
(172,1,2,NULL,"2022-10-19 21:28:52"),
(173,8,1,NULL,"2022-10-19 21:29:15"),
(174,8,2,NULL,"2022-10-19 21:31:25"),
(175,2,1,NULL,"2022-10-19 21:31:32"),
(176,2,2,NULL,"2022-10-19 21:32:34"),
(177,8,1,NULL,"2022-10-19 21:32:41"),
(178,8,2,NULL,"2022-10-19 21:39:36"),
(179,8,1,NULL,"2022-10-19 21:39:44"),
(180,8,2,NULL,"2022-10-20 08:25:11"),
(181,2,1,NULL,"2022-10-20 08:26:49"),
(182,2,2,NULL,"2022-10-20 08:26:56"),
(183,1,1,NULL,"2022-10-20 08:26:59"),
(184,2,1,NULL,"2022-10-20 08:32:26"),
(185,1,2,NULL,"2022-10-20 08:36:06"),
(186,1,1,NULL,"2022-10-20 08:36:07"),
(187,1,2,NULL,"2022-10-20 08:37:03"),
(188,3,1,NULL,"2022-10-20 08:37:11"),
(189,3,2,NULL,"2022-10-20 08:37:16"),
(190,8,1,NULL,"2022-10-20 08:37:43"),
(191,8,2,NULL,"2022-10-20 08:37:59"),
(192,5,1,NULL,"2022-10-20 08:38:03"),
(193,5,2,NULL,"2022-10-20 08:40:30"),
(194,5,1,NULL,"2022-10-20 08:40:33"),
(195,5,2,NULL,"2022-10-20 08:46:12"),
(196,5,1,NULL,"2022-10-20 08:46:14"),
(197,5,2,NULL,"2022-10-20 08:46:26"),
(198,5,1,NULL,"2022-10-20 08:46:27"),
(199,5,2,NULL,"2022-10-20 08:47:33"),
(200,1,1,NULL,"2022-10-20 08:47:37"),
(201,1,2,NULL,"2022-10-20 08:47:43"),
(202,8,1,NULL,"2022-10-20 08:55:51"),
(203,8,2,NULL,"2022-10-20 08:57:42"),
(204,3,1,NULL,"2022-10-20 08:57:44"),
(205,3,2,NULL,"2022-10-20 09:01:11"),
(206,4,1,NULL,"2022-10-20 09:01:16"),
(207,4,2,NULL,"2022-10-20 09:02:18"),
(208,2,2,NULL,"2022-10-20 09:03:50"),
(209,2,1,NULL,"2022-10-20 09:03:55"),
(210,2,2,NULL,"2022-10-20 09:04:13"),
(211,2,1,NULL,"2022-10-20 09:04:14"),
(212,2,2,NULL,"2022-10-20 09:13:24"),
(213,4,1,NULL,"2022-10-20 09:13:31"),
(214,6,1,NULL,"2022-10-20 09:15:33"),
(215,4,2,NULL,"2022-10-20 09:16:35"),
(216,3,1,NULL,"2022-10-20 09:16:38"),
(217,2,1,NULL,"2022-10-20 09:17:30"),
(218,3,2,NULL,"2022-10-20 09:20:38"),
(219,8,1,NULL,"2022-10-20 09:20:46"),
(220,8,2,NULL,"2022-10-20 09:22:00"),
(221,5,1,NULL,"2022-10-20 09:22:06"),
(222,5,2,NULL,"2022-10-20 09:23:19"),
(223,1,1,NULL,"2022-10-20 09:23:21"),
(224,1,2,NULL,"2022-10-20 09:23:35"),
(225,6,2,NULL,"2022-10-20 09:23:56"),
(226,1,1,NULL,"2022-10-20 09:23:59"),
(227,1,2,NULL,"2022-10-20 09:25:20"),
(228,3,1,NULL,"2022-10-20 09:25:24"),
(229,3,2,NULL,"2022-10-20 09:26:20"),
(230,2,2,NULL,"2022-10-20 09:27:42"),
(231,2,1,NULL,"2022-10-20 09:27:55"),
(232,3,1,NULL,"2022-10-20 09:28:48"),
(233,3,2,NULL,"2022-10-20 09:29:09"),
(234,8,1,NULL,"2022-10-20 09:34:03"),
(235,2,2,NULL,"2022-10-20 09:36:07"),
(236,8,2,NULL,"2022-10-20 09:40:46"),
(237,2,1,NULL,"2022-10-20 09:40:51"),
(238,2,2,NULL,"2022-10-20 09:41:34"),
(239,8,1,NULL,"2022-10-20 09:41:40"),
(240,8,2,NULL,"2022-10-20 09:44:50"),
(241,5,1,NULL,"2022-10-20 09:44:55"),
(242,5,2,NULL,"2022-10-20 09:45:48"),
(243,1,1,NULL,"2022-10-20 09:45:55"),
(244,3,1,NULL,"2022-10-20 09:47:10"),
(245,3,2,NULL,"2022-10-20 09:47:47"),
(246,1,2,NULL,"2022-10-20 09:49:27"),
(247,5,1,NULL,"2022-10-20 09:49:31"),
(248,5,2,NULL,"2022-10-20 09:51:02"),
(249,3,1,NULL,"2022-10-20 09:51:05"),
(250,3,2,NULL,"2022-10-20 09:51:07"),
(251,2,1,NULL,"2022-10-20 09:51:11"),
(252,2,2,NULL,"2022-10-20 09:51:48"),
(253,2,1,NULL,"2022-10-20 09:51:50"),
(254,2,2,NULL,"2022-10-20 09:52:26"),
(255,2,1,NULL,"2022-10-20 09:53:32"),
(256,2,2,NULL,"2022-10-20 09:55:50"),
(257,8,1,NULL,"2022-10-20 09:55:59"),
(258,8,2,NULL,"2022-10-20 09:57:33"),
(259,3,1,NULL,"2022-10-20 09:58:32"),
(260,3,2,NULL,"2022-10-20 09:59:26"),
(261,2,1,NULL,"2022-10-20 09:59:31"),
(262,3,1,NULL,"2022-10-20 10:00:22"),
(263,3,2,NULL,"2022-10-20 10:00:44"),
(264,2,2,NULL,"2022-10-20 10:04:42"),
(265,8,1,NULL,"2022-10-20 10:04:57"),
(266,8,2,NULL,"2022-10-20 10:07:19"),
(267,2,1,NULL,"2022-10-20 10:07:23"),
(268,2,2,NULL,"2022-10-20 10:12:16"),
(269,5,1,NULL,"2022-10-20 10:12:21"),
(270,3,1,NULL,"2022-10-20 10:16:14"),
(271,5,2,NULL,"2022-10-20 10:18:09"),
(272,1,1,NULL,"2022-10-20 10:18:13"),
(273,3,2,NULL,"2022-10-20 10:22:12"),
(274,1,2,NULL,"2022-10-20 10:22:16"),
(275,8,1,NULL,"2022-10-20 10:22:21"),
(276,8,2,NULL,"2022-10-20 10:24:07"),
(277,5,1,NULL,"2022-10-20 10:24:35"),
(278,5,2,NULL,"2022-10-20 10:26:30"),
(279,3,1,NULL,"2022-10-20 10:26:36"),
(280,3,2,NULL,"2022-10-20 10:27:30"),
(281,4,1,NULL,"2022-10-20 10:29:09"),
(282,2,1,NULL,"2022-10-20 10:29:54"),
(283,4,2,NULL,"2022-10-20 10:30:14"),
(284,4,1,NULL,"2022-10-20 10:30:38"),
(285,4,2,NULL,"2022-10-20 10:32:07"),
(286,1,1,NULL,"2022-10-20 10:32:11"),
(287,1,2,NULL,"2022-10-20 10:36:39"),
(288,2,2,NULL,"2022-10-20 10:36:51"),
(289,2,1,NULL,"2022-10-20 10:36:53"),
(290,2,2,NULL,"2022-10-20 10:37:17"),
(291,2,1,NULL,"2022-10-20 10:37:22"),
(292,2,2,NULL,"2022-10-20 10:42:00"),
(293,9,1,NULL,"2022-10-20 10:42:05"),
(294,9,2,NULL,"2022-10-20 10:42:23"),
(295,3,1,NULL,"2022-10-20 10:42:27"),
(296,3,2,NULL,"2022-10-20 10:42:56"),
(297,1,1,NULL,"2022-10-20 10:43:00"),
(298,1,2,NULL,"2022-10-20 10:44:11"),
(299,3,1,NULL,"2022-10-20 10:44:37"),
(300,3,2,NULL,"2022-10-20 10:46:32"),
(301,4,1,NULL,"2022-10-20 10:46:42"),
(302,3,1,NULL,"2022-10-20 10:46:54"),
(303,4,2,NULL,"2022-10-20 10:52:52"),
(304,5,1,NULL,"2022-10-20 10:52:57"),
(305,5,2,NULL,"2022-10-20 10:54:00"),
(306,3,2,NULL,"2022-10-20 10:54:29"),
(307,3,1,NULL,"2022-10-20 10:54:39"),
(308,3,2,NULL,"2022-10-20 11:17:25"),
(309,2,1,NULL,"2022-10-20 11:19:33"),
(310,2,2,NULL,"2022-10-20 11:26:18"),
(311,4,1,NULL,"2022-10-20 11:26:32"),
(312,4,2,NULL,"2022-10-20 11:27:38"),
(313,3,1,NULL,"2022-10-20 11:27:43"),
(314,3,2,NULL,"2022-10-20 11:30:17"),
(315,5,1,NULL,"2022-10-20 11:30:23"),
(316,5,2,NULL,"2022-10-20 11:32:17"),
(317,1,1,NULL,"2022-10-20 11:32:30"),
(318,3,1,NULL,"2022-10-20 11:33:37"),
(319,3,2,NULL,"2022-10-20 11:33:52"),
(320,1,2,NULL,"2022-10-20 11:34:51"),
(321,5,1,NULL,"2022-10-20 11:45:33"),
(322,2,1,NULL,"2022-10-20 11:46:03"),
(323,2,2,NULL,"2022-10-20 11:46:11"),
(324,5,2,NULL,"2022-10-20 11:46:20"),
(325,1,1,NULL,"2022-10-20 11:48:33"),
(326,2,1,NULL,"2022-10-20 12:06:19"),
(327,1,2,NULL,"2022-10-20 12:18:24"),
(328,3,1,NULL,"2022-10-20 12:18:49"),
(329,2,2,NULL,"2022-10-20 12:23:59"),
(330,3,2,NULL,"2022-10-21 14:04:12"),
(331,3,1,NULL,"2022-10-31 16:20:57"),
(332,3,2,NULL,"2022-10-31 16:21:00"),
(333,4,1,NULL,"2022-10-31 16:26:11"),
(334,4,2,NULL,"2022-10-31 16:30:25"),
(335,3,1,NULL,"2022-10-31 16:30:37"),
(336,3,2,NULL,"2022-10-31 16:30:53"),
(337,3,1,NULL,"2022-10-31 16:30:55"),
(338,3,2,NULL,"2022-10-31 16:31:13"),
(339,6,1,NULL,"2022-10-31 16:31:19"),
(340,6,2,NULL,"2022-10-31 16:33:15"),
(341,3,1,NULL,"2022-10-31 16:33:20"),
(342,3,2,NULL,"2022-10-31 16:40:25"),
(343,8,1,NULL,"2022-10-31 16:40:47"),
(344,8,2,NULL,"2022-10-31 16:47:08"),
(345,2,1,NULL,"2022-10-31 16:47:11"),
(346,2,2,NULL,"2022-10-31 16:48:21"),
(347,8,1,NULL,"2022-10-31 16:48:26"),
(348,8,2,NULL,"2022-10-31 16:52:24"),
(349,5,1,NULL,"2022-10-31 16:52:29"),
(350,5,2,NULL,"2022-10-31 16:55:09"),
(351,2,1,NULL,"2022-10-31 16:55:14"),
(352,2,2,NULL,"2022-10-31 17:01:21"),
(353,10,1,NULL,"2022-10-31 17:01:26"),
(354,10,2,NULL,"2022-10-31 17:01:46"),
(355,1,1,NULL,"2022-10-31 17:01:51");


DROP TABLE IF EXISTS `tblsignosvitales`;

CREATE TABLE `tblsignosvitales` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `CodConsulta` int(11) NOT NULL,
  `Peso` decimal(6,0) DEFAULT NULL,
  `Altura` decimal(4,0) DEFAULT NULL,
  `Presion_Arterial` varchar(6) DEFAULT NULL,
  `Frecuencia_Respiratoria` varchar(6) DEFAULT NULL,
  `Frecuencia_Cardiaca` varchar(6) DEFAULT NULL,
  `Temperatura` decimal(6,0) DEFAULT NULL,
  `HoraRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `CodEnfermera` int(11) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodConsulta` (`CodConsulta`),
  KEY `CodEnfermera` (`CodEnfermera`),
  CONSTRAINT `tblsignosvitales_ibfk_1` FOREIGN KEY (`CodConsulta`) REFERENCES `tblconsulta` (`Codigo`),
  CONSTRAINT `tblsignosvitales_ibfk_2` FOREIGN KEY (`CodEnfermera`) REFERENCES `tblempleado` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblsignosvitales` VALUES (1,1,190,190,190,190,190,40,"2022-10-13 13:19:56",3),
(4,7,180,170,110,110,110,39,"2022-10-19 19:31:04",6),
(5,8,110,110,40,40,40,39,"2022-10-20 09:16:29",6),
(6,10,150,175,30,30,30,45,"2022-10-31 16:33:09",6);


DROP TABLE IF EXISTS `tblsintomasdiagnostico`;

CREATE TABLE `tblsintomasdiagnostico` (
  `idSintomaDiagnostico` int(11) NOT NULL AUTO_INCREMENT,
  `sintoma` int(11) NOT NULL,
  `diagnostico` int(11) NOT NULL,
  PRIMARY KEY (`idSintomaDiagnostico`),
  KEY `sintoma` (`sintoma`),
  KEY `diagnostico` (`diagnostico`),
  CONSTRAINT `tblsintomasdiagnostico_ibfk_1` FOREIGN KEY (`sintoma`) REFERENCES `catsintomas` (`idSintoma`),
  CONSTRAINT `tblsintomasdiagnostico_ibfk_2` FOREIGN KEY (`diagnostico`) REFERENCES `tbldiagnosticoconsulta` (`Codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblsintomasdiagnostico` VALUES (1,2,1),
(2,1,2),
(3,2,3),
(4,6,3),
(5,7,4),
(6,2,4),
(7,5,4),
(8,1,5),
(9,4,5),
(10,5,5);


DROP TABLE IF EXISTS `tblsolicitudcompra`;

CREATE TABLE `tblsolicitudcompra` (
  `idSolicitudCompra` int(11) NOT NULL AUTO_INCREMENT,
  `solicitante` int(11) NOT NULL,
  `estadoSolicitud` int(11) NOT NULL,
  `fechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `descripcionSolicitud` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idSolicitudCompra`),
  KEY `solicitante` (`solicitante`),
  KEY `estadoSolicitud` (`estadoSolicitud`),
  CONSTRAINT `tblsolicitudcompra_ibfk_1` FOREIGN KEY (`solicitante`) REFERENCES `tblempleado` (`Codigo`),
  CONSTRAINT `tblsolicitudcompra_ibfk_2` FOREIGN KEY (`estadoSolicitud`) REFERENCES `catestadocompra` (`idEstadoCompra`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblsolicitudcompra` VALUES (1,8,6,"2022-10-19 21:13:29",""),
(2,8,6,"2022-10-19 21:15:50",""),
(4,8,6,"2022-10-19 21:33:27","Stock vacío"),
(5,8,6,"2022-10-20 09:42:13","Es ejemplo"),
(6,8,1,"2022-10-20 10:07:12","Se solicita 50 omeprazol"),
(7,8,6,"2022-10-31 16:49:28","Compra ejemplo");


DROP TABLE IF EXISTS `tbltipodecambio`;

CREATE TABLE `tbltipodecambio` (
  `idCambio` int(11) NOT NULL AUTO_INCREMENT,
  `Moneda` int(11) NOT NULL,
  `CambioReferencia` decimal(10,0) NOT NULL,
  `aperturaCaja` int(11) NOT NULL,
  PRIMARY KEY (`idCambio`),
  KEY `aperturaCaja` (`aperturaCaja`),
  CONSTRAINT `tbltipodecambio_ibfk_1` FOREIGN KEY (`aperturaCaja`) REFERENCES `tblaperturacaja` (`idApertura`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbltipodecambio` VALUES (1,2,36,20);


DROP TABLE IF EXISTS `tblusuarios`;

CREATE TABLE `tblusuarios` (
  `Codigo` int(11) NOT NULL AUTO_INCREMENT,
  `NombreUsuario` varchar(14) NOT NULL,
  `Pass` varchar(200) NOT NULL,
  `CodPersonaU` int(11) NOT NULL,
  `Estado` tinyint(4) DEFAULT NULL,
  `imgUsuario` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `CodPersonaU` (`CodPersonaU`),
  KEY `Estado` (`Estado`),
  CONSTRAINT `tblusuarios_ibfk_1` FOREIGN KEY (`CodPersonaU`) REFERENCES `tblpersona` (`Codigo`),
  CONSTRAINT `tblusuarios_ibfk_2` FOREIGN KEY (`Estado`) REFERENCES `catestado` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblusuarios` VALUES (1,"ADMINISTRADOR","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",1,1,"FotosReferencia/1666276562_WhatsApp Image 2022-10-20 at 8.34.51 AM.jpeg"),
(2,"GERENTE","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",2,1,"FotosReferencia/1666278250_WhatsApp Image 2022-10-20 at 9.03.02 AM.jpeg"),
(3,"DOCTOR","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",3,1,"FotosReferencia/Enrique.jpeg"),
(4,"RECEPCIONISTA","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",4,1,"FotosReferencia/1666235865_WhatsApp Image 2022-10-19 at 6.47.29 PM.jpeg"),
(5,"Cajero","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",5,1,"FotosReferencia/1666276827_Tamaño carnet.jpg"),
(6,"ENFERMERA","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",6,1,"FotosReferencia/Enfermera.png"),
(7,"DOCTORR","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",7,1,NULL),
(8,"FARMACEUTA","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",8,1,"FotosReferencia/Farmaceuta.png"),
(9,"Doctor3","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",11,2,""),
(10,"UsuarioEjemplo","NjBmZHlXY2YweHVuSUg3MVkrME0zdz09",13,1,"");


DROP TABLE IF EXISTS `tblventafarmacia`;

CREATE TABLE `tblventafarmacia` (
  `idVentaFarmacia` int(11) NOT NULL AUTO_INCREMENT,
  `recetaMedica` int(11) NOT NULL,
  `servicio` int(11) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  `fechaVenta` date NOT NULL,
  `fechaRegistro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`idVentaFarmacia`),
  KEY `recetaMedica` (`recetaMedica`),
  KEY `servicio` (`servicio`),
  CONSTRAINT `tblventafarmacia_ibfk_1` FOREIGN KEY (`recetaMedica`) REFERENCES `tblrecetamedicamentos` (`Codigo`),
  CONSTRAINT `tblventafarmacia_ibfk_2` FOREIGN KEY (`servicio`) REFERENCES `tblserviciosbrindados` (`idServiciosBrindados`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblventafarmacia` VALUES (1,1,8,"Paciente satisfecho","2022-10-19","2022-10-19 21:30:19"),
(2,2,10,"Descripción","2022-10-20","2022-10-20 09:21:55"),
(3,1,11,"","2022-10-20","2022-10-20 10:23:39"),
(4,3,14,"Se completó la venta","2022-10-31","2022-10-31 16:42:37");


SET foreign_key_checks = 1;
